
let () =
  if 0 = 0
  then ()
  else ()